---
name: ai-smart-customer-service-app
description: Template for creating AI smart customer service applications. ONLY trigger when user explicitly requests to CREATE/BUILD an AI customer service app (e.g., "创建智能客服应用", "做一个AI客服", "build an AI chatbot", "create a customer service bot").
_meta_type: template
_meta_template_name: web
---

## Prerequisites

1. Initialize Project (if needed):
```bash
REPO_ROOT/.genie/scripts/bash/setup-project.sh web --sub-type ai-smart-customer-service
```

2. **Generate `docs/product/features.md` before writing any code** — product overview, core features, user stories, page structure, data models, API endpoints.

**Validation**: If `docs/product/features.md` does not exist, STOP and create it first.

3. Make a best design by SKILL: `ui-ux-pro-max` for first time
4. Use SKILL `text-to-image` for generating images, icons, or illustrations when needed.
5. Use the SKILL `*-integrator` to fully realize the user's needs.
6. **CRITICAL: Set up database tables using TCB**
```
bash /workspace/.codebuddy/skills/genie-tcb-db-integrator/scripts/tcb-pg-migrate.sh --project-dir /workspace --sql "CREATE TABLE ..."
```

**CRITICAL**: On the first conversation, after initializing the project (REPO_ROOT/.genie/scripts/bash/setup-project.sh web --sub-type ai-smart-customer-service), end the current conversation turn immediately and inform the user that the project has been generated.

## Best Practices

### General Principles

- **Perfect Architecture**: Refactor when needed, eliminate duplication, maintain clean separation
- **Parallel Tool Calls**: Execute independent operations simultaneously
- **Less is More**: Quality over quantity unless enterprise landing page requested
- **Leverage Existing Dependencies**: Prefer existing libraries over new ones
- **Animations**: Use the **ui-animation** skill for all animation needs (MotionPrimitives for page transitions, ReactBits for creative effects)

### SEO (Automatic for All Pages)

- Title tags under 60 chars with keyword
- Meta description max 160 chars
- Single H1 matching page intent
- Semantic HTML (`<header>`, `<nav>`, `<main>`, `<footer>`, `<article>`, `<section>`)
- Image alt attributes with keywords
- JSON-LD for products/articles/FAQs
- Lazy loading for images
- Canonical tags

## Web Template Architecture

```
/
├── backend/                           # Express.js + TypeScript
│   ├── package.json
│   ├── tsconfig.json
│   ├── jest.config.mjs
│   ├── eslint.config.js
│   ├── .env / .env.example
│   └── src/
│       ├── index.ts                   # Server entry point
│       ├── app.ts                     # Express configuration
│       ├── config/
│       │   ├── env.ts                 # Environment validation (Zod)
│       │   └── logger.ts              # Pino logger factory
│       ├── lib/
│       │   └── hunyuan-chat.ts        # Hunyuan AI chat integration
│       ├── modules/
│       │   ├── chat.ts                # Chat API endpoints
│       │   └── system.ts              # Health check endpoints
│       ├── types/
│       │   └── chat.types.ts          # Chat type definitions
│       ├── middleware/
│       │   ├── errorHandler.ts
│       │   ├── logger.ts
│       │   └── validation.ts
│       └── __tests__/
│           ├── setup.ts
│           └── system.test.ts
│
├── frontend/                          # React 19 + Vite
│   ├── package.json
│   ├── vite.config.ts
│   ├── tailwind.config.ts
│   ├── components.json                # shadcn/ui config
│   ├── index.html
│   └── src/
│       ├── main.tsx                   # Entry point
│       ├── App.tsx                    # Root component with providers
│       ├── index.css                  # Global styles + Tailwind theme
│       ├── components/
│       │   ├── chat/                  # Chat components
│       │   │   ├── ChatInput.tsx
│       │   │   ├── ChatMessage.tsx
│       │   │   ├── ChatWindow.tsx
│       │   │   └── ConversationList.tsx
│       │   └── ui/                    # shadcn/ui components
│       ├── hooks/
│       │   ├── use-chat.ts
│       │   └── use-mobile.ts
│       ├── lib/
│       │   ├── api-client.ts          # Axios with interceptors
│       │   └── utils.ts               # cn utility
│       ├── pages/
│       │   ├── Index.tsx
│       │   └── NotFound.tsx
│       └── types/
│           └── chat.ts
│
└── docs/
    ├── project.json
    ├── pages.json
    ├── design/
    │   └── default.style-guide.html
    ├── posters/
    │   └── app/
    │       └── app-poster.png
    └── product/
        └── features.md
```


## AI Chat Backend

Text conversation is powered by **TokenHub** over the OpenAI-compatible protocol
(Bearer token auth). Genie's sandbox provides zero-config credentials, so a
generated project can chat out of the box.

The runnable client, default model and dependencies live in the **Template**
(`backend/src/lib/hunyuan-chat.ts`, `backend/package.json`) — treat the Template
as the single source of truth. Do NOT restate SDK names, model names, endpoints
or env vars in this Skill, and do NOT copy the LLM client code here (that would
create a second implementation that drifts). When extending chat behaviour,
reuse the `hunyuan-chat-integrator` skill's conventions.

## Technical References

Detailed implementation patterns in `references/`:

- **[api-protocol.md](references/api-protocol.md)**: JSON-based API standard (CRITICAL - no URL parameters for data operations)
- **[frontend-patterns.md](references/frontend-patterns.md)**: Import management, React Router compatibility, WebSocket
- **[architecture.md](references/architecture.md)**: Complete monorepo structure, key files, commands

## Quick Reference

### Adding New Resources

**Frontend:**
1. Define types in `src/types/[resource].ts`
2. Create hooks in `src/hooks/use-[resources].ts`
3. Build components using JSON-based API calls

**Backend:**
1. Create types in `src/types/[resource].types.ts`
2. Create module in `src/modules/[resource].ts`
3. Register router in `src/app.ts`

### Key Commands

```bash
# Debugging
python3 "$PROJECT_ROOT/.genie/scripts/python/fetch_monitor_errors.py"
```

### Critical Rules

1. **JSON Protocol**: All data operations use POST with JSON body, not URL parameters
2. **BrowserRouter Only**: No Data Router features (ScrollRestoration, useMatches, etc.)
3. **Import Everything**: Every component/function used must be imported
4. **53 shadcn/ui Components**: Use existing, DO NOT create custom versions
5. **WebSocket**: Must use `/api` prefix and dynamic protocol/host
6. **oklch Color Format**: ALL color CSS variables in `index.css` MUST use `oklch()` format. NEVER use bare HSL (`220 14% 96%`), hex, hsl(), or rgb().

### Launch Configuration

`.cloudstudio` file defines startup - DO NOT modify. Always use unified process script.
